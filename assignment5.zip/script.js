function refresh()
{
  var refresh=1000;
  mytime=setTimeout('displayClock()',refresh)
}

function displayClock() 
{
  var x = new Date()
  document.getElementById('clock').innerHTML = x;
  refresh();
  
  document.getElementById('header').style.background =
               'rgb(' + Math.round(Math.random() * 255) +
               ',' + Math.round(Math.random() * 255) +
               ',' + Math.round(Math.random() * 255) + ')';
    
  document.getElementById('menu').style.background =
               'rgb(' + Math.round(Math.random() * 255) +
               ',' + Math.round(Math.random() * 255) +
               ',' + Math.round(Math.random() * 255) + ')';
  
  document.getElementById('main').style.background =
               'rgb(' + Math.round(Math.random() * 255) +
               ',' + Math.round(Math.random() * 255) +
               ',' + Math.round(Math.random() * 255) + ')';
  
  document.getElementById('right').style.background =
               'rgb(' + Math.round(Math.random() * 255) +
               ',' + Math.round(Math.random() * 255) +
               ',' + Math.round(Math.random() * 255) + ')';
  
  document.getElementById('footer').style.background =
               'rgb(' + Math.round(Math.random() * 255) +
               ',' + Math.round(Math.random() * 255) +
               ',' + Math.round(Math.random() * 255) + ')'; 
}


